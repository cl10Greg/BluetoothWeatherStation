/* 
 * File:   Humidity.h
 * Author: ggirard
 *
 * Created on December 3, 2013, 9:32 AM
 */

#ifndef HUMIDITY_H
#define	HUMIDITY_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* HUMIDITY_H */


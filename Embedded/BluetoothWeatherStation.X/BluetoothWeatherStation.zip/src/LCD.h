/* 
 * File:   LCD.h
 * Author: ggirard
 *
 * Created on December 12, 2013, 3:13 PM
 */

#ifndef LCD_H
#define	LCD_H

void initLCD();


#endif	/* LCD_H */


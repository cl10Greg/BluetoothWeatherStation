/* 
 * File:   Command.h
 * Author: ggirard
 *
 * Created on December 13, 2013, 2:09 PM
 */

#ifndef COMMAND_H
#define	COMMAND_H

//check read/write
void getCommands();
void setCommands();

#endif	/* COMMAND_H */


//LCD: HC164001YFHLYB
/* LCD Pinout
 * RS:      RD0
 * R/W:     RD1
 * E:       RD2
 * D4:      RD4
 * D5:      RD5
 * D6:      RD6
 * D7:      RD7
 */

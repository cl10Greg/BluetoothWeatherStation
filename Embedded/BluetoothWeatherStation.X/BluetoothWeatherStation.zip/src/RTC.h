/* 
 * File:   RTC.h
 * Author: ggirard
 *
 * Created on December 3, 2013, 9:32 AM
 */

#ifndef RTC_H
#define	RTC_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* RTC_H */


/* 
 * File:   customADC.h
 * Author: ggirard
 *
 * Created on December 3, 2013, 3:28 PM
 */

#ifndef CUSTOMADC_H
#define	CUSTOMADC_H

void initADC();
void selectTemp();
void selectHumidity();


#endif	/* CUSTOMADC_H */


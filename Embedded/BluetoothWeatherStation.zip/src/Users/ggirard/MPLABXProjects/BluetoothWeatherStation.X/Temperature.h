/* 
 * File:   Temperature.h
 * Author: ggirard
 *
 * Created on December 3, 2013, 9:31 AM
 */

#ifndef TEMPERATURE_H
#define	TEMPERATURE_H

unsigned int readTemp();

#endif	/* TEMPERATURE_H */

